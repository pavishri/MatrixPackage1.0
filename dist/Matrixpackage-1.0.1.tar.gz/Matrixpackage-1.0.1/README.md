# **Matrixpackage**

Matrix Package is a PYPI package that includes a method that performs addition,subtraction and multiplication for the matrices using functions.

# **Installation**

Run the following to install:
'''cmd 
pip install Matrixpackage==1.0.2
'''
# **Usage**

Install the package in our device. 
We could use this package for matrix operations.
This method receives two mandatory parameters.
The first and second parameters are received dynamically and passed in the code.


# Version==1.0
# Released Date:25Feb2021
# Author:Pavithra.K, Maria Irudaya Regilan J


